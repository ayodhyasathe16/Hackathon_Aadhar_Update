﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Update : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("idCard.html");
    }
    static int ticket, distance, fee, charges, entryfee, total, tour_id;
    protected void txtticket_TextChanged(object sender, EventArgs e)
    {
        /*ticket = Convert.ToInt32(txtticket.Text);
        distance = Convert.ToInt32(Request.QueryString["distance"]);
        fee = Convert.ToInt32(Request.QueryString["fee"]);

        charges = (distance * ticket) * 2;
        txtcharges.Text = "mobile OTP : Rs: " + charges.ToString();

        entryfee = (fee * ticket);
        txtfee.Text = "Entry Fee : Rs: " + entryfee.ToString();

        total = charges + entryfee;

        txttotal.Text = "Total Charges : Rs: " + total.ToString();*/

    }
    protected void ddlpaymode_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlpaymode.SelectedItem.Text == "CASH")
        {
            panel1.Visible = false;
        }
        else
        {
            panel1.Visible = true;
        }
    }
}